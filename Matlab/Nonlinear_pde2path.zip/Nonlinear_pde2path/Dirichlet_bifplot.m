clear all
close all
clc

lam=(4-sqrt(6))/(3-sqrt(6));
lc=pi*sqrt(4-sqrt(6));
l2=linspace(0,1,1e3);
a=6*sqrt(2)*sqrt(103*sqrt(2)-84*sqrt(3))*sqrt(l2)...
    /(sqrt(pi)*(-2*sqrt(2)*sqrt(3)+8)^(1/4)*sqrt(-1381*sqrt(2)*sqrt(3)+3404));
hold on

plot([3 lc],[1 1],'k','linewidth',3,'color',0.7*[1 1 1])
pc=plot([lc 5],[1 1],'k','linewidth',1,'color',0.7*[1 1 1]);
n1=1;
n2=700;
load('./Super_only_bp1_b/pt780.mat')
pb=plot(p.branch(4,n1:n2),p.branch(end-1,n1:n2),'linewidth',3,'color',0.7*[1 1 1]); %Plots branch max
plot(p.branch(4,n1:n2),p.branch(end,n1:n2),'linewidth',3,'color',0.7*[1 1 1]) %Plots branch min

pa=plot(lc+l2,1+a*lam,'b--','linewidth',3);
plot(lc+l2,1-a*lam,'b--','linewidth',3)


xlim([3.8 4.5])

xlabel('$L$')
ylabel('Steady state amplitudes, $U$')
set(gca,'fontsize',15)
h=legend([pb,pc,pa],'Stable amplitudes','Unstable amplitudes','Weakly nonlinear results','location','best');
set(h,'FontSize',15);
export_fig('..\..\Pictures\Pitchfork_example.png','-r300')
