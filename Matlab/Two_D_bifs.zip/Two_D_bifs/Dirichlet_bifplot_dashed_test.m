ccc

ks=1:5;
G33=[-5 -3 -1 1 2];

ii=0;
unstabx=[];
unstabyn=[];
unstabyp=[];
stabx=[];
stabyn=[];
stabyp=[];
for k=2%ks
    % subplot(1,5,k)
    figure('units','normalized','position',[0 0.1 0.2 0.4])
    S=findLargestPtFiles({['Region',num2str(k),'Spot']});
    ii=ii+1;
    for j=1:2
        load(S{j})
        hold on
        n1=1;
        n2=length(p.branch(8,:));
        for i=n1:n2-1 % loop from first-point to last point
            lw=1;
            if(~ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i)  ==0);
                stabx=[stabx p.branch(4,i:i+1)];
                stabyn=[stabyn p.branch(end-1,i:i+1)];
                stabyp=[stabyp p.branch(end,i:i+1)];
            elseif ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i+1)==0
                stabx=[stabx p.branch(4,i:i+1)];
                stabyn=[stabyn p.branch(end-1,i:i+1)];
                stabyp=[stabyp p.branch(end,i:i+1)];
            else
                unstabx=[unstabx p.branch(4,i:i+1)];
                unstabyn=[unstabyn p.branch(end-1,i:i+1)];
                unstabyp=[unstabyp p.branch(end,i:i+1)];
            end
            % if( ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i+1)==0); lw=3;  end
            %
            % plot(p.branch(4,i:i+1),p.branch(end-1,i:i+1),'r','Linewidth',lw);
            % plot(p.branch(4,i:i+1),p.branch(end,i:i+1),'r','Linewidth',lw);

        end
    end

    % S=findLargestPtFiles({['Region',num2str(k),'Line']});
    % ii=ii+1;
    % for j=1:2
    %     load(S{j})
    %     hold on
    %     n1=1;
    %     n2=length(p.branch(8,:));
    %     for i=n1:n2-1 % loop from first-point to last point
    %         lw=1;
    %         if(~ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i)  ==0); lw=3;  end
    %         if( ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i+1)==0); lw=3;  end
    %
    %         plot(p.branch(4,i:i+1),p.branch(end-1,i:i+1),'b','Linewidth',lw);
    %         plot(p.branch(4,i:i+1),p.branch(end,i:i+1),'b','Linewidth',lw);
    %
    %     end
    % end


end
[stabx,stabyp,stabyn]=filter_large_jumps_3d_iterative(stabx,stabyp,stabyn, 1);
[unstabx,unstabyp,unstabyn]=filter_large_jumps_3d_iterative(unstabx,unstabyp,unstabyn, 0.1);
plot(stabx,stabyp,'b-',stabx,stabyn,'b-')
plot(unstabx,unstabyp,'b--',unstabx,unstabyn,'b--')
xlim([4 5])
ylim([0 2.5])
xlabel('$L$')
ylabel('Steady state amplitudes, $U$')
set(gca,'FontSize',20);
% axis equal
% export_fig(['..\..\Pictures\G3_',num2str(G33(k)),'.png'],'-r300')

function largestFileNames = findLargestPtFiles(folderList)
% Initialise cell array to store largest file names for each folder
largestFileNames = {};

% Loop through each folder name in the folder list
for i = 1:length(folderList)
    % Define the folder paths
    x_folder = folderList{i};
    x_bp1_folder = strcat(x_folder, 'bp1b');

    % Process each folder individually
    folderNames = {x_folder, x_bp1_folder};
    for j = 1:length(folderNames)
        folderName = folderNames{j};

        % Get all files matching the pattern ptY.mat in the folder
        files = dir(fullfile(folderName, 'pt*.mat'));

        % If there are no matching files, skip to the next folder
        if isempty(files)
            fprintf('No ptY.mat files found in folder %s\n', folderName);
            continue;
        end

        % Extract the Y values from the filenames
        Y_values = arrayfun(@(f) str2double(regexprep(f.name, 'pt(\d+)\.mat', '$1')), files);

        % Find the maximum Y value
        [~, idx] = max(Y_values);

        % Construct the path in the required format and store it
        largestFileNames{end+1} = fullfile('.', folderName, files(idx).name); %#ok<AGROW>
    end
end

% Convert cell array to string array
largestFileNames = string(largestFileNames);
end
function [x_filtered, y_filtered, z_filtered] = filter_large_jumps_3d_iterative(x, y, z, tau)
    % filter_large_jumps_3d_iterative - Filters out points in x, y, and z
    % where the jump between consecutive points exceeds the threshold tau
    % in any dimension, iterating until no jumps remain.
    %
    % Syntax:
    %   [x_filtered, y_filtered, z_filtered] = filter_large_jumps_3d_iterative(x, y, z, tau)
    %
    % Inputs:
    %   x - Vector of x data points
    %   y - Vector of y data points
    %   z - Vector of z data points
    %   tau - Threshold for allowable jumps
    %
    % Outputs:
    %   x_filtered - Filtered x vector
    %   y_filtered - Filtered y vector
    %   z_filtered - Filtered z vector
    %
    % Example:
    %   x = [1, 2, 3, 10, 11];
    %   y = [1, 2, 2.5, 15, 16];
    %   z = [1, 1, 1, 20, 21];
    %   tau = 5;
    %   [x_f, y_f, z_f] = filter_large_jumps_3d_iterative(x, y, z, tau);

    % Input validation
    if length(x) ~= length(y) || length(x) ~= length(z)
        error('x, y, and z must have the same length.');
    end
    if tau <= 0
        error('Threshold tau must be positive.');
    end

    % Initialise filtered data
    x_filtered = x;
    y_filtered = y;
    z_filtered = z;
    changes_made = true;

    % Iterate until no changes are made
    while changes_made
        changes_made = false;
        keep = true(size(x_filtered)); % Logical array to mark points to keep
        
        % Check for large jumps
        for i = 1:length(x_filtered) - 1
            if abs(x_filtered(i+1) - x_filtered(i)) > tau || ...
               abs(y_filtered(i+1) - y_filtered(i)) > tau || ...
               abs(z_filtered(i+1) - z_filtered(i)) > tau
                keep(i+1) = false; % Mark point as to be removed
                changes_made = true;
            end
        end

        % Apply the filtering
        x_filtered = x_filtered(keep);
        y_filtered = y_filtered(keep);
        z_filtered = z_filtered(keep);
    end

    % % Optional: Plot the results
    % figure;
    % plot3(x, y, z, 'ro-', 'DisplayName', 'Original Data'); % Original data in red
    % hold on;
    % plot3(x_filtered, y_filtered, z_filtered, 'bo-', 'DisplayName', 'Filtered Data'); % Filtered data in blue
    % legend('show');
    % xlabel('x');
    % ylabel('y');
    % zlabel('z');
    % title('Filtered 3D Data Plot (Iterative)');
    % grid on;
end
