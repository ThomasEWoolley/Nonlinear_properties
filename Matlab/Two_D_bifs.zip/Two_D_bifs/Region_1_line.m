%% Code for cleaning folders and memory
close all;clc;keep pphome;
Fname=['Region1Line'];

if exist(Fname, 'dir')
    rmdir([Fname,'*'],'s')
end

% for gvv=3:0.1:4
gvv=-5;

p=[]; p=stanparam(p); % Setting up basic p structure
p.plot.auxdict={'L','$d_v$','$g_u$','$g_v$','$gvv$','$\max u_1$','$\min u_1$'}; % Parameter names (not needed, but nice)
par=           [ 3.5 10 3.5 2 gvv]; % Parameters used in functions and Jacobian
p.fuha.outfu=@outfn; % Output function to be plotted, names are in above.
p.nc.ilam=1; % Parameter number to continue over
p.plot.bpcmp=6; % Which component of output function to plot.
p.plot.pcmp=1; % Component for plotting
huclean(p); % Set up figures in nice way

% p.fuha.ufu=@myufu;    % printout
p.sw.sfem=-1; % Use OOPDE settings. Otherwise 0/1 for full/preassembled FEM settings
p.nc.neq=2; % Number of equations

p.fuha.sG=@sG; % Functions to be solved
p.sw.jac=0; % Use numeric Jacobian.

p.dim=2; % Spatial dimensions
lx=.5;ly=lx;nx=20;ny=nx;
sw.sym=2;
pde=stanpdeo2D(lx,ly,nx,ny,sw); % PDE setup
p.pdeo=pde;p.np=pde.grid.nPoints;p.nu=2*p.np;p.nt=pde.grid.nElements;
p.sw.verb=0; % Verbosity of calculation
p.sol.xi=1/p.nu; % Normalisation weights

p.np=p.pdeo.grid.nPoints; p.nu=2*p.np; p.sol.xi=1/(p.nu);

p.fuha.cfu=@cf; % Semi-implicit part (in functions and Jacobian)

p.sw.bifcheck=2; % Calculate bifurcations using eigenvalues, 0 turn off, 1 use LU decomposition
p.sw.spcalc=1; % Calculate eigenvalues (0/1 Eigenvalue computations off/on)
p.nc.neig=min(20,p.np); % Number of eigenvalues to calculate
p.nc.tol=1e-11; % Tolerance for finding branch

p.sol.ds=0.001; % Arclength step
p.nc.dsmin=1e-7; % Arclength minimum steplength
p.nc.dsmax=0.1; % Arclength max steplength
p.nc.dlammax=0.1; % Maximum step in the parameter
p.nc.lammax=6; % Max parameter value
p.nc.lammin=0; % Min parameter value
p.file.smod=10; % Output every n steps

p.plot.pstyle=1; %0 only plot the FEM mesh; 1 mesh-plot; 2 density-plot
p.sw.para=1; % Continuation variable 1: automatic switching via ? <> p.nc.lamdtol (0: natural parameter.; 2: arclength).

p.nc.mu1=0.5; % Threshold for bifcheck=2
p.nc.mu2=1e-5; % Threshold for bifcheck=2
p.nc.bisecmax=100;
p.nc.dsminbis=1e-12;

u=ones(p.np,1); v=ones(p.np,1); %ICs
% Fname=['Other_stst'];
% u=ones(p.np,1)*1/(4*par(5))*(par(2)-2*par(4)+4*par(5)); v=ones(p.np,1)*1/(4*par(5))*(-par(2)+2*par(4)+4*par(5)); %ICs
% Fname=['zero'];
% u=ones(p.np,1)*0.001; v=ones(p.np,1)*0.001; %ICs
p.u=[u; v; par']; % Complete description

p=oosetfemops(p);
p.nc.nsteps=50;
p=setfn(p,Fname,0.01);
p.sw.verb=0; % Verbosity of calculation
p.sw.inter=0; % Verbosity of calculation
p=cont(p,5000);
%%
p=swibra(Fname,'bpt1',[Fname,'bp1b'],0.001);
p.nc.dsmax=0.01; % Arclength max steplength
p=cont(p,1000);
% %%
% p=swibra(Fname,'bpt2',[Fname,'_bp2_b'],0.001);
% p.nc.lammax=10; % Max parameter value
% p.nc.dsmax=0.01; % Arclength max steplength
% p=cont(p,1000);

% end

function r=sG(p,u) % pde for Schnak
par=u(p.nu+1:end); %{'a', 'b','d'}
u=u(1:p.nu);n=p.np;u1=u(1:n); u2=u(n+1:2*n); % Seperate parameters and variables
L=par(1);
dv=par(2);
gu=par(3);
gv=par(4);
gvv=par(5);


f1=(u1-1).*u1.*u2+(u2-1).*u1.*u2;
f2=-gu*(u1-1).*u2.*u1-(u2-1).*u2.*u1*gv+(u2-1).^2.*u2.*u1*gvv;

f=[f1;f2]; % Nonlinear kinetics

gr=p.pdeo.grid; fem=p.pdeo.fem; % Grid components
K=p.mat.K; N=spd(zeros(n,1));

% Qu=p.mat.Qu; Qv=p.mat.Qv; bcu=p.mat.Gu; bcv=p.mat.Gv;
r=[K/L^2 N; N dv*K/L^2]*[u1;u2]-p.mat.M*f; % putting the equation together
end

function A=spd(v)
n=length(v);
A=spdiags(v,0,n,n);
end


function out=outfn(p,u)
% output to bifurcation diagram function
% u=u(1:p.nu);n=p.np;u1=u(1:n); u2=u(n+1:2*n); % Seperate parameters and variables
out=[u(p.nu+1:end); % parameters
    max(u(1:p.np));
    min(u(1:p.np))];
end




function [p,cstop]=myufu(p,brout,ds)

p=ulamcheck(p); % test if a desired lambda value has been passed
brplot=brout(length(bradat(p))+p.plot.bpcmp); %y-axis value in bif-figure
% fprintf('%4i %s %s %5.2e %4i  %s %s ', ...
%     p.file.count,printcon(getlam(p)),printcon(brplot),p.sol.res,p.sol.iter, ...
%     p.sol.meth,printcon(ds));
% if(p.sw.errcheck>0) fprintf('%5.2e ',p.sol.err);end
% if(p.sw.spcalc==1) fprintf(' %2i ', p.sol.ineg); end;
% npr=length(p.sw.bprint);
% for i=1:npr; fprintf('%s ',printcon(brout(length(bradat(p))+p.sw.bprint(i)))); end;
% put anything else here

cstop=0;
if(getlam(p)<p.nc.lammin)
    fprintf('  lam=%g < lammin=%g, stopping\n',getlam(p),p.nc.lammin); cstop=1;
    fprintf('\n');
end
if(getlam(p)>p.nc.lammax)
    fprintf('  lam=%g > lammax=%g, stopping\n',getlam(p),p.nc.lammax); cstop=1;
    fprintf('\n');
end
end

