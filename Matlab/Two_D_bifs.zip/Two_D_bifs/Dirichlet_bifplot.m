ccc

ks=1:5;
G33=[-5 -3 -1 1 2];

ii=0;

for k=ks
    % subplot(1,5,k)
    figure('units','normalized','position',[0 0.1 0.2 0.4])
    S=findLargestPtFiles({['Region',num2str(k),'Spot']});
    ii=ii+1;
    for j=1:2
        load(S{j})
        hold on
        n1=1;
        n2=length(p.branch(8,:));
        for i=n1:n2-1 % loop from first-point to last point
            lw=1;
            if(~ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i)  ==0); lw=3;  end
            if( ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i+1)==0); lw=3;  end

            plot(p.branch(4,i:i+1),p.branch(end-1,i:i+1),'r','Linewidth',lw);
            plot(p.branch(4,i:i+1),p.branch(end,i:i+1),'r','Linewidth',lw);

        end
    end

    S=findLargestPtFiles({['Region',num2str(k),'Line']});
    ii=ii+1;
    for j=1:2
        load(S{j})
        hold on
        n1=1;
        n2=length(p.branch(8,:));
        for i=n1:n2-1 % loop from first-point to last point
            lw=1;
            if(~ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i)  ==0); lw=3;  end
            if( ismember(p.branch(2,i),[-2 -1 1 2]) && p.branch(3,i+1)==0); lw=3;  end

            plot(p.branch(4,i:i+1),p.branch(end-1,i:i+1),'b','Linewidth',lw);
            plot(p.branch(4,i:i+1),p.branch(end,i:i+1),'b','Linewidth',lw);

        end
    end

    xlim([4 5])
    ylim([0 2.5])
    xlabel('$L$')
    ylabel('Steady state amplitudes, $U$')
    set(gca,'FontSize',20);
    % axis equal
    % export_fig(['..\..\Pictures\G3_',num2str(G33(k)),'.png'],'-r300')
end




function largestFileNames = findLargestPtFiles(folderList)
% Initialise cell array to store largest file names for each folder
largestFileNames = {};

% Loop through each folder name in the folder list
for i = 1:length(folderList)
    % Define the folder paths
    x_folder = folderList{i};
    x_bp1_folder = strcat(x_folder, 'bp1b');

    % Process each folder individually
    folderNames = {x_folder, x_bp1_folder};
    for j = 1:length(folderNames)
        folderName = folderNames{j};

        % Get all files matching the pattern ptY.mat in the folder
        files = dir(fullfile(folderName, 'pt*.mat'));

        % If there are no matching files, skip to the next folder
        if isempty(files)
            fprintf('No ptY.mat files found in folder %s\n', folderName);
            continue;
        end

        % Extract the Y values from the filenames
        Y_values = arrayfun(@(f) str2double(regexprep(f.name, 'pt(\d+)\.mat', '$1')), files);

        % Find the maximum Y value
        [~, idx] = max(Y_values);

        % Construct the path in the required format and store it
        largestFileNames{end+1} = fullfile('.', folderName, files(idx).name); %#ok<AGROW>
    end
end

% Convert cell array to string array
largestFileNames = string(largestFileNames);
end

